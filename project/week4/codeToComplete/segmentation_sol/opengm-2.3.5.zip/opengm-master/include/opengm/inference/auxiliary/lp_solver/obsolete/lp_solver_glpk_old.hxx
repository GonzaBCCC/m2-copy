#pragma once
#ifndef OPENGM_LP_SOLVER_GLPK_HXX
#define OPENGM_LP_SOLVER_GLPK_HXX

#endif