#ifndef OPENGM_PYTHON_GIL
#define OPENGM_PYTHON_GIL

class releaseGIL{
public:
    inline releaseGIL(){
        save_state = PyEval_SaveThread();
    }

    inline ~releaseGIL(){
        PyEval_RestoreThread(save_state);
    }
private:
    PyThreadState *save_state;
};

#endif