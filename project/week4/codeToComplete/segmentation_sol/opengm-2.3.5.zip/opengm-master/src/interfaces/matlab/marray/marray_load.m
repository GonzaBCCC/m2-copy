function M = marray_load(file_name, dataset_name)
%
M = hdf5read(file_name, dataset_name);
%
end