Import Opengm
-------------
To import opengm just type::

    import opengm
 
 
